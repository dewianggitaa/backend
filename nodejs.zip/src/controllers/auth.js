const usersModel = require('../models/users')

exports.createNewUser = async (req, res) => {
    const {body} = req;
    try {
        await usersModel.createNewUser(body);
        const result = {
            message: 'Register Successfully',
            data: body
        }
        res.status(201).json(result);
    } catch (error) {
        res.status(500).json({
            message: 'Server Error',
            serverMessage: error
        })
    }
}

exports.getAllUsers = async (req, res, next) => {
    try {
        const [data] = await usersModel.getAllUsers();
        const result = {
            message: 'Get All User Succes',
            data: data,
        }
    res.status(201).json(result);
    } catch (error) {
        res.status(500).json({
            message: 'Server Error',
            serverMessage: error,
        })
    }
}

exports.updateUser = async (req, res, next) => {
    const {idUser} = req.params;
    const {body} = req;
    try {
        await usersModel.updateUser(body, idUser);
        const result = {
            message: 'Update Success!',
            data: {
                id: idUser,
                ...body
            }
        }
        res.status(201).json(result);
    } catch (error) {
        res.status(500).json({
            message: 'Server Error',
            serverMessage: error,
        })
    }
}

exports.deleteUser = async (req, res, next) => {
    const {idUser} = req.params;
    try {
        await usersModel.deleteUser(idUser);
        const result= {
            message: 'Delete Success!',
            data: null
        }
        res.status(201).json(result);
    } catch (error) {
        res.status(500).json({
            message: 'Server Error',
            serverMessage: error,
        })
    } 
}